# Fire Alarm System using Arduino Uno

## CIRCUIT DIAGRAM

![](circuit2.png)


## SYSTEM ARCHITECTURE

![](arc3.png)


## LINK FOR WRITTEN BLOG

